package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController(value="/")
public class MyController {
	@GetMapping
	public String simple(){
		System.out.println("<h1>HelloWorld !!</h1>");
		return "<h1>HelloWorld !!</h1>";
		
	}
}
