package controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import vo.Emp;

@RestController
public class EmpController {
	private List<Emp> list = new ArrayList<Emp>();
	@GetMapping(produces=
		{MediaType.APPLICATION_JSON_VALUE, 
		MediaType.APPLICATION_XML_VALUE})
	public List<Emp> list(){
		System.out.println("list = " + list.size());
		return list;
	}
	
	
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public String create(@RequestBody Emp emp){
		System.out.println("in create " + emp);
		list.add(emp);
		return "<h1>Inserted</h1>";
	}
}
