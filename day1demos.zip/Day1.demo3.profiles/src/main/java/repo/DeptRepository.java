package repo;

import org.springframework.data.jpa.repository.JpaRepository;

import entities.Dept;

public interface DeptRepository extends JpaRepository<Dept,Integer> 
{

}
