package controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import entities.Dept;
import repo.DeptRepository;

@RestController
public class DeptController {
	@Autowired
	private DeptRepository repo;
	
	@GetMapping(produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Dept> list(){
		return repo.findAll();
	}
	
	@PostMapping(consumes=MediaType.APPLICATION_JSON_VALUE)
	public String create(@RequestBody Dept dept ){
		System.out.println("creat " + dept);
		repo.save(dept);
		return "<h1>Inserted</h1>";
	}
}
