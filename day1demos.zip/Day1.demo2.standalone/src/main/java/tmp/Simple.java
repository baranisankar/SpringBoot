package tmp;

import org.springframework.stereotype.Component;

@Component
public class Simple {
	public void m1(){
		System.out.println("m1 method invoked ....");
	}
}
