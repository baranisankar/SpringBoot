package demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import tmp.Simple;

@SpringBootApplication(scanBasePackages="tmp")
public class StandaloneApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx  = SpringApplication.run(StandaloneApplication.class,args);
		Simple s = ctx.getBean(Simple.class);
		s.m1();
	}

}
